package com.example.capstone_idoeat.retrofit

interface ApiService {
    //
}