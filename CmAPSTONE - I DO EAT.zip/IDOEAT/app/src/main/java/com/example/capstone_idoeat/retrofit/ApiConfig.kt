package com.example.capstone_idoeat.retrofit

object ApiConfig {
    //ica baru aja bilang kalau login register udah bisa, nunggu
    //fdsnfhdsnhfndshfdsfdsfsd
}